class Conta:
    def __init__(self, numero, titular, saldo, limite, data_abertura):
        self.numero = numero
        self.titular = titular
        self.saldo = saldo
        self.limite = limite
        self.data_abertura = data_abertura
        self.historico = Historico()
    
    def deposita(self, valor):
        self.saldo += valor
        self.historico.adicionar_transacao("Depósito", valor)
    
    def saca(self,valor):
        if (self.saldo < valor):
            self.historico.adicionar_transacao("Saque (falha)", valor)
            return False
        else:
            self.saldo -= valor
            self.historico.adicionar_transacao("Saque", valor)
            return True
        
    def transfere_para(self, destino, valor):
        if self.saca(valor):
            destino.deposita(valor)
            self.historico.adicionar_transacao(f"Transferência para conta {destino.numero}", valor)
            return True
        return False

    def extrato(self):
        print("="*40)
        print("Numero: {} \nSaldo: R$ {}".format(self.numero,self.saldo))
        if isinstance(self.titular, Cliente):
             print("Titular: {} {}\nCPF: {}".format(
                self.titular.nome, self.titular.sobrenome, self.titular.cpf))
        else:
            print("Titular: {}".format(self.titular))

    def __str__(self):
        return f"Conta: {self.numero}, Saldo: R$ {self.saldo:.2f}, Titular: {self.titular}" 

class Cliente:
    def __init__(self, nome,sobrenome, cpf):
        self.nome = nome
        self.sobrenome = sobrenome
        self.cpf =cpf

    def __str__(self):
        return f"{self.nome} {self.sobrenome}, CPF: {self.cpf}"

class Data:
    def __init__(self, dia, mes, ano):
        self.dia = dia
        self.mes = mes
        self.ano = ano

    def __str__(self):
        return f"{self.dia:02d}/{self.mes:02d}/{self.ano}"

class Historico:
    def __init__(self):
        self.transacao = []
    
    def adicionar_transacao(self, descricao, valor):
        self.transacao.append("{}: R$ {}".format(descricao, valor))

    def mostrar(self):
        if self.transacao:
            print("="*40)
            print("Histórico de Transações:")
            for transacao in self.transacao:
                print(transacao)
        else:
            print("Nenhuma transação realizada.")
        print("="*40)


#area de testes
if __name__ == '__main__':
    cliente1 = Cliente("João", "Silva", "123456789")

    data_abertura = Data(15, 11, 2024)

    conta1 = Conta("123-4", cliente1, 120.0, 1000.0, data_abertura)

    conta1.deposita(50)
    conta1.saca(30)
    conta1.transfere_para(conta1, 20)

    conta1.extrato()
    conta1.historico.mostrar()