from datetime import datetime

class Banco:
    def __init__(self, nome, cnpj, endereco):
        self.nome = nome
        self.cnpj = cnpj
        self.endereco = endereco
        self.lista_usuarios = []

    def adicionar_usuario(self, usuario):
        self.lista_usuarios.append(usuario)

    def listar_usuarios(self):
        for usuario in self.lista_usuarios:
            print(f"Nome: {usuario.nome}, CPF: {usuario.cpf}")


class Usuario:
    def __init__(self, nome, cpf, endereco, telefone, email):
        self.nome = nome
        self.cpf = cpf
        self.endereco = endereco
        self.telefone = telefone
        self.email = email


class Gerente(Usuario):
    def __init__(self, nome, cpf, endereco, telefone, email, cargo, setor):
        super().__init__(nome, cpf, endereco, telefone, email)
        self.cargo = cargo
        self.setor = setor

    def remover_cliente(self, cliente, banco):
        if cliente in banco.lista_usuarios:
            banco.lista_usuarios.remove(cliente)
            print(f"Cliente {cliente.nome} removido com sucesso.")
        else:
            print("Cliente não encontrado.")

    def cadastrar_cliente(self, cliente, banco):
        banco.adicionar_usuario(cliente)
        print(f"Cliente {cliente.nome} cadastrado com sucesso.")

    def aprovar_emprestimo(self, emprestimo):
        if emprestimo.valor <= 50000: #aprovar empréstimos até 50 mil
            print("Empréstimo aprovado.")
            return True
        else:
            print("Empréstimo recusado.")
            return False

    def analisar_conta(self, conta):
        print(f"Conta {conta.numero_conta} analisada com sucesso.")
        print(f"Saldo atual: R${conta.saldo:.2f}")


class Cliente(Usuario):
    def __init__(self, nome, cpf, endereco, telefone, email, id_cliente):
        super().__init__(nome, cpf, endereco, telefone, email)
        self.id_cliente = id_cliente
        self.contas = []

    def acessar_conta(self, numero_conta):
        for conta in self.contas:
            if conta.numero_conta == numero_conta:
                print(f"Acessando conta {numero_conta}. Saldo: R${conta.saldo:.2f}")
                return conta
        print("Conta não encontrada.")
        return None

    def consultar_saldo(self):
        for conta in self.contas:
            print(f"Conta {conta.numero_conta}: Saldo = R${conta.saldo:.2f}")

    def transferir(self, conta_origem, conta_destino, valor):
        if conta_origem.sacar(valor):
            conta_destino.depositar(valor)
            print(f"Transferência de R${valor:.2f} realizada com sucesso.")
        else:
            print("Transferência não realizada.")

    def solicitar_emprestimo(self, emprestimo):
        print(f"Solicitação de empréstimo de R${emprestimo.valor:.2f} enviada.")


class Conta:
    def __init__(self, numero_conta, tipo, saldo, cartao):
        self.numero_conta = numero_conta
        self.tipo = tipo
        self.saldo = saldo
        self.cartao = cartao

    def sacar(self, valor):
        if self.saldo >= valor:
            self.saldo -= valor
            print(f"Saque de R${valor:.2f} realizado com sucesso.")
            return True
        else:
            print("Saldo insuficiente.")
            return False

    def depositar(self, valor):
        self.saldo += valor
        print(f"Depósito de R${valor:.2f} realizado com sucesso.")

    def transferir(self, valor, conta_destino):
        if self.sacar(valor):
            conta_destino.depositar(valor)
            print(f"Transferência de R${valor:.2f} realizada com sucesso.")
        else:
            print("Transferência não realizada.")

    def investir(self, valor):
        if self.saldo >= valor:
            self.saldo -= valor
            print(f"Investimento de R${valor:.2f} realizado com sucesso.")
        else:
            print("Saldo insuficiente para investir.")


class Cartao:
    def __init__(self, numero_cartao, validade, senha, tipo_cartao):
        self.numero_cartao = numero_cartao
        self.validade = validade
        self.senha = senha
        self.tipo_cartao = tipo_cartao

    def realizar_compra(self, valor, senha_informada):
        if senha_informada == self.senha:
            print(f"Compra de R${valor:.2f} realizada com sucesso.")
            return True
        else:
            print("Senha incorreta. Compra não autorizada.")
            return False

    def validar_pagamento(self):
        print("Pagamento validado com sucesso.")


class Emprestimo:
    def __init__(self, id_emprestimo, valor, data, juros):
        self.id_emprestimo = id_emprestimo
        self.valor = valor
        self.data = data
        self.juros = juros

    def calcular_valor_final(self):
        valor_final = self.valor * (1 + self.juros / 100)
        print(f"Valor final do empréstimo: R${valor_final:.2f}")
        return valor_final


class Transacao:
    def __init__(self, id_transacao, valor, data, tipo):
        self.id_transacao = id_transacao
        self.valor = valor
        self.data = data
        self.tipo = tipo

    def executar(self):
        print(f"Transação {self.tipo} de R${self.valor:.2f} realizada em {self.data}.")