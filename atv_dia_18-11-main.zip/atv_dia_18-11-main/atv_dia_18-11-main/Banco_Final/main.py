from utils import Banco, Usuario, Cliente, Gerente, Cartao, Conta, Emprestimo, Transacao

def sistema_bancario():
    print("Bem-vindo ao Banco POO!")

    banco = Banco(nome="Banco POO", cnpj="12.345.678/0001-99", endereco="Rua Universidade Federal, 42")

    while True:
        print("\nEscolha uma opção:")
        print("1. Cadastrar Cliente")
        print("2. Criar Conta para Cliente")
        print("3. Consultar Saldo")
        print("4. Realizar Transferência")
        print("5. Solicitar Empréstimo")
        print("6. Listar Clientes do Banco")
        print("7. Cadastrar Gerente")
        print("8. Listar Gerentes")
        print("9. Sair")
        
        opcao = input("Digite o número da opção desejada: ")

        if opcao == "1":

            nome = input("Nome do cliente: ")
            cpf = input("CPF do cliente: ")
            endereco = input("Endereço do cliente: ")
            telefone = input("Telefone do cliente: ")
            email = input("Email do cliente: ")
            id_cliente = len(banco.lista_usuarios) + 1

            cliente = Cliente(nome, cpf, endereco, telefone, email, id_cliente)
            print(f"Cliente {nome} cadastrado com sucesso!")
            banco.lista_usuarios.append(cliente)

        elif opcao == "2":
            # Criar Conta para Cliente
            cpf = input("Informe o CPF do cliente: ")
            cliente = next((c for c in banco.lista_usuarios if isinstance(c, Cliente) and c.cpf == cpf), None)
            if cliente:
                numero_conta = int(input("Número da conta: "))
                tipo = input("Tipo da conta (Corrente/Poupança): ")
                saldo = float(input("Saldo inicial: "))
                usar_cartao = input("Deseja criar um cartão para essa conta? (s/n): ")

                if usar_cartao.lower() == "s":
                    numero_cartao = input("Número do cartão: ")
                    validade = input("Validade do cartão (MM/AA): ")
                    senha = input("Senha do cartão: ")
                    tipo_cartao = input("Tipo do cartão (Crédito/Débito): ")
                    cartao = Cartao(numero_cartao, validade, senha, tipo_cartao)
                else:
                    cartao = None

                conta = Conta(numero_conta, tipo, saldo, cartao)
                cliente.contas.append(conta)
                print("Conta criada com sucesso!")
            else:
                print("Cliente não encontrado.")

        elif opcao == "3":
            # Consultar Saldo
            cpf = input("Informe o CPF do cliente: ")
            cliente = next((c for c in banco.lista_usuarios if isinstance(c, Cliente) and c.cpf == cpf), None)
            if cliente:
                cliente.consultar_saldo()
            else:
                print("Cliente não encontrado.")

        elif opcao == "4":
            # Realizar Transferência
            cpf_origem = input("CPF do cliente que fará a transferência: ")
            cliente_origem = next((c for c in banco.lista_usuarios if isinstance(c, Cliente) and c.cpf == cpf_origem), None)
            if cliente_origem:
                numero_conta_origem = int(input("Número da conta de origem: "))
                conta_origem = next((c for c in cliente_origem.contas if c.numero_conta == numero_conta_origem), None)
                if conta_origem:
                    cpf_destino = input("CPF do cliente que receberá a transferência: ")
                    cliente_destino = next((c for c in banco.lista_usuarios if isinstance(c, Cliente) and c.cpf == cpf_destino), None)
                    if cliente_destino:
                        numero_conta_destino = int(input("Número da conta de destino: "))
                        conta_destino = next((c for c in cliente_destino.contas if c.numero_conta == numero_conta_destino), None)
                        if conta_destino:
                            valor = float(input("Valor da transferência: "))
                            cliente_origem.transferir(conta_origem, conta_destino, valor)
                        else:
                            print("Conta de destino não encontrada.")
                    else:
                        print("Cliente de destino não encontrado.")
                else:
                    print("Conta de origem não encontrada.")
            else:
                print("Cliente de origem não encontrado.")

        elif opcao == "5":
            # Solicitar Empréstimo
            cpf = input("Informe o CPF do cliente: ")
            cliente = next((c for c in banco.lista_usuarios if isinstance(c, Cliente) and c.cpf == cpf), None)
            if cliente:
                valor = float(input("Valor do empréstimo: "))
                juros = float(input("Taxa de juros (%): "))
                data = datetime.now()
                id_emprestimo = len(cliente.contas) + 1
                emprestimo = Emprestimo(id_emprestimo, valor, data, juros)
                cliente.solicitar_emprestimo(emprestimo)
                print("Solicitação de empréstimo registrada. Aguardando aprovação.")
            else:
                print("Cliente não encontrado.")

        elif opcao == "6":
            # Listar Clientes
            print("\nClientes cadastrados no banco:")
            for usuario in banco.lista_usuarios:
                if isinstance(usuario, Cliente):
                    print(f"- Nome: {usuario.nome}, CPF: {usuario.cpf}")

        elif opcao == "7":
            # Cadastrar Gerente
            nome = input("Nome do gerente: ")
            cpf = input("CPF do gerente: ")
            endereco = input("Endereço do gerente: ")
            telefone = input("Telefone do gerente: ")
            email = input("Email do gerente: ")
            cargo = input("Cargo do gerente: ")
            setor = input("Setor do gerente: ")

            gerente = Gerente(nome, cpf, endereco, telefone, email, cargo, setor)
            print(f"Gerente {nome} cadastrado com sucesso!")
            banco.lista_usuarios.append(gerente)

        elif opcao == "8":
            # Listar Gerentes
            print("\nGerentes cadastrados no banco:")
            for usuario in banco.lista_usuarios:
                if isinstance(usuario, Gerente):
                    print(f"- Nome: {usuario.nome}, CPF: {usuario.cpf}, Cargo: {usuario.cargo}, Setor: {usuario.setor}")

        elif opcao == "9":
            print("Encerrando o sistema. Obrigado por usar o Banco POO!")
            break

        else:
            print("Opção inválida. Tente novamente.")

sistema_bancario()